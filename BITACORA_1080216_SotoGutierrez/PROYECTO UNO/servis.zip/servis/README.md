# SERVIS 
### *Distributed Servers System*

> SERVIS is a software written in C++ and designed to simulate a real distribution of a set of petitions in servers systems. It uses basic syntax of pointers in C++ in order to reduce the demand of memory in servers, while it tries to complete incoming petitions as fast as possible. SERVIS is focused on maximize the use of resources, and for that, it has a group of functions that take and operate every petition in the best way possible.


## Index:
1. Manual
2. History
3. General Information
---
## 1. Manual 
### About the .txt files:
Information is gathered it from .txt files and saved *´inside´* the program. This means .txt files should contain all the information, including servers parameters, of the petitions that should be operate.All .txt files must be in the same directory as .exe is. The main .txt file must be called *"servis.txt"*, and this is the file that has the settings for servers:

```C++
// File: servis.txt
// Should first contain server parameters: ram | processor | operations
10 7 10
8 9 6
3 3 2
```
Notices that there are no spaces just after the last value o before the first one. Also, files can have comments on it, one per line and starting them with //. Comments cannot be in the same line of values:

```C++
// File: servis.txt
// Should first contain: ram | processor | operations
10 7 10
8 9 6
3 3 2 // this is server three.
```
> The line `3 3 2 // this is server three` will be denied by SERVIS and the program will be stoped.

SERVIS can read up to ten more .txt files. Those must be called `thefile#.txt` where the `#` is a number between 1 and 10. Those only contains petitions, and notice, there are not blank lines between petitions. Petitions must be like this:

```C++
// File: thefile1.txt
// Only DIV petitions
OPERATION
processor values
ram values 
//Example
DIV
1 6 7 9 5
2 5 8 9 7
```
>Petions can be on any .txt file, including servis.txt, but in case of using servis.txt, servers parameter must be first. `thefile#.txt` files only contains petitions

### About the petitions and operations

SERVIS can operate five basic types of petitions. These petitions have a specific structure that must be follow in order to accomplish the petition. Any kind of petition requires a gruop of values to RAM memory, and another group of values to PROCESSOR memory.

| Function or Method | PROCESSOR values needed | RAM values needed | Description |
| :----------------: | :---------: | :-------- | :---------: |
| SUM | 5 values | 3 values | Sums all RAM values |
| SUB | 3 values | 4 values | Substracts all RAM values |
| MUL | 3 values | 6 values | Sums the 6 RAM values, and multiplies the result by the last value. |
| DIV | 5 values | 5 values | Sums the first 4 RAM values, and divides it by the last value. |
| NEG | 2 values | 1 value  | Multiplies per -1 the value on RAM. |

Values are integers and of course,not letters or characters. For example:

```C++
//thefile1.txt
//Correct DIV petition.
DIV
1 2 3 4 5
1 8 6 4 9
//Incorrect DIV petition.
DIV
1.2 2 8 6 7
a 7 b 9 7 6
//Values can be negative.
DIV
-1 -7 -5 -6 -2
-8 -9 -5 -4 -3
//Oher valid values.
DIV
845 785 6598 7845 12248
22235 457 9895 477 5651
```

### About the resutls:

Results are shown on screen while petitions are being operated. When all petitions are accomplished, all results are saved in a txt file called "results.txt" and also a summary is shown on screen.

---
## 2. HISTORY 2016
---
* October 06:
    * First implementation of Lectura class. Features:
        *  Open and close a .txt file. 
        *  Read(): reads content of .txt files. 
---
* October 12:
    * First implementation of Node class.
    * First implementation of Cola class. Features:
        * Queue(): queue values.
        * Dequeue(): dequeue values.
        * Front(): return value of first element in queue.
        * Count(): return the total number of elements in queue.
        * IsEmpty(): Return true whether the queue is empty, otherwise, return false.
    * First implementation of Servers class. Features:
        * isFull(): returns true whether the server is full, otherwise, return false.
        * AcceptPetition(): servers now are ready to accept or refuse a petition, through consult themselves if they have enough memory to handle a new petition.
        * Now servers can save values in their RAM memory and PROCESSOR memory, but still need a new method to complement this function.
---
* October 24:
    * First implementation of HardDrive class. Features:
        * Move(): move HardDrive to the position required.
        * Position(): return the current position of HardDrive.
    * Fixed a bug in Cola class that makes VS C++ compiler to crash.
    * Lectura class now save information from .txt files into an array of strings.
    * Major changes in Servers class. Features:
        *  isFull() has been changed to IsNotEmpty().
        *  IsNotEmpty(): returns true whether the server has values of a petition on it.
        *  Movements(): new function added. Returns the minimum operations needed to move HardDrive to the position required by current petition.
        *  ValuesInProcessorOfFirstPetitionInQueue(): new function added. Returns the total numbers of values that belongs to current petition.
        *  MemoryDequeue() & ProcessorDequeue(): now only dequeues a value if server has at least 1 operation available. Otherwise, it does not make changes.
        *  AssignValues(): new method added.This complements the AcceptPetition(). Now server can accept petitions and save its values.
        *  Constructor added. Now servers has a new default constructor. It requires more parameters needed for servers.
        *  ToSuccessful(): new method added. When a petition has been operated in any servers it is send to Succesful queue.
        *  Operate(): new method added. Operates the values of current petition saved by server. When finished, it calls ToSuccesful().
    * First implementation of BalanceadorDeCarga class. Features:
        * Split(): split a string and save the substrings into an array of ints. Returns the array.
        * Values(): returns the first set of values of a petitions, already splitted. It returns an array of ints.
        * ServerBuilder(): calls the Servers::Servers() default constructor and gives it the parameters received from "servis.txt".
        * WriteResults(): basic and first attempt to show on screen the process of operate the petitions.
        * Allocator(): it defines which server is ready to accept the current petition. Consult servers if they are available to accept, and then, calls Servers::AssignValues().
        * RequiredMovements(): consults servers for the HardDrive position they need to operate, and returns the minimun operations server must do to move HardDrive.
        * Operate(): defines the basic order in which servers should received the command to operate.
        *  Start(): this calls Allocator() and Operate() as many times as needed to complete petitions.
        *  ToUnsuccessful(): if a petition is not accepted by any server, then is send it to Unsuccessful queue.
---

* October 30:
    * BalanceadorDeCarga modified.
        * vector<int> has been changed to Cola instance. Now vectors are only used to string values. int values are saved in Cola instances. This also applies for those functions that used to return vector<int> values.
        * WriteResults(): this functions has been rewritten. Now shows complete real-time information.
        * ID(): new function added. Now all petitions has an unique ID.
        * Allocator() has been rewritten. Now first tries to fill all servers instead of fills only one at the same time.
        * RequiredMovements() deleted. Now this informations is provided for Servers class.
        * Operate(): due tu RequiredMovements() has been deleted, this method also has changed. Now this evaluates if servers has something to operate and then analyzes the basic order in which servers should received the command to operate.
    * Cola class modified:
        * Dequeue(): now this functions returns the value of the element to be dequeued. A bug has been fixed in which the method does not link the other elements correctly.
        * ValueAtIndex(): new functions added. Returns the value of the element on the positions required. If index is out of range, returns -1.
    * Lectura class modified:
        * Read(): now analyzes and identifies general errors in petitions. If exists an error that could not be fixed, gives to user an alert and stops the program.
        * Push(): new method added. Now Read() function calls this to save the string read from .txt file.
        * Now Lectura class can read up to 10 diferents files without including "servis.txt".
        * Now .txt files can have comments on it. 
    * Servers class modified:
        * Default constructor modified to receive Log pointer.
        * ToSuccessful() has been modified to make it smaller.
        * NameOfPetition(): new function added. Returns the name of the operations of the current petition in server.
        * IsUsed: new function added. Returns true whether the server has received a petition in current tick.


## 3. GENERAL INFORMATION

###  Main classes:

* *Cola*
* *Lectura*
* *Servers*
* *BalanceadorDeCarga*

###  Other important classes:

* *Node*
* *HardDrive*

### Cola & Node:

> SERVIS uses *Queues* implementations to simulate RAM memory and PROCESSOR memory of  the servers. Node class provides the objects that later are linked in Cola Class.

| Function or Method | Description | Parameter |
| :-------: | :------: | :----- |
| Queue( **int** *value* ) | *Adds a new element to queue.* | **int** *value*: value of the new element to be added.
| Dequeue() | *Erases the first element in queue and return the value of it.* | ***none*** |
| Front() | *Returns the value of first element in queue. It does **not** erase it.* | ***none*** |
| IsEmpty() | *Returns **true** whenever the server is empty, otherwise returns **false**.* | ***none*** |
| Count() | *Returns the total number of elements in queue.* | ***none*** |
| ValueAtIndex( **int** *index* ) | *Returns the value of the node in position 'index' in queue. If index is higher than Count(), returns -1.* | **int** *index*: position in queue, which value is expected. |

### Lectura:

> Petitions are provided by a txt file. It also contains the parameters of the three servers implemented in SERVIS. Lectura class has the main function to read txt files, capture the inforrmation and save it, ready to use for SERVIS.

| Function or Method | Description | Parameter |
| :-------: | :------: | :----- |
| Read() | *Opens the txt file, reads it and returns a vector<string> with lines from the file in it.* | ***none*** |
| Push()| *Analyzes the line read from .txt file and decides if it is correct or not. For example: values should not contain letters, just numbers.* | ***none***|

**Note**: the name of the main file must be "servis.txt", and the file itself must be in the same directory as .exe. "servis.txt" should have, at least, the parameters for serves.

```C
// Comments in file must be like this.
// Files cannot have empty lines.
// File: servis.txt
// Should first contain: ram | processor | operations
10 7 10
8 9 6
3 3 2
// The following petition will be denied because incorrect syntaxis of comments.
SUB // Very important operation :)
1 2 3
4 5 6 7 
```

You can also add as much petitions as you want ( *see -Operations- section before*) in "servis.txt", but if you'd rather, you can add new .txt files, named as thefile#.txt ( '#' should be a number between 1 and 9), with more petitions.

### HardDrive:

> Defines the hardrive used for SERVIS. Each server needs HardDrive to be located in a specific position in order to perform the operation required by petition.

| Function or Method | Description | Parameter |
| :-------: | :------: | :----- |
| Move( **int** *position* )| *Locate HardDrive in the positions required.* | **int** *position*: value of position required. |
| Position() | *Returns the actual position of HardDrive* | ***none*** |

### Servers

> Contains all the functions and methods that SERVIS needs to successfuly complete the set of petitions required. This class decides whether a petitions is accepted or not, but does not care if petitions are correctly build.
> Servers class has many functions and methods, but this document only describes the most important ones.

| Function or Method | Description | Parameter |
| :-------: | :------: | :----- |
| IsNotEmpty() & IsUsed() | *Both returns true whether a server has one o more petitions to resolve. First one is used to know if server must continue operating or not. Last one is used to know if server has accepted a petition on current tick.* | ***none*** |
| AcceptPetition( ***int*** *_operation*) | *Analyzes the operation required by incoming petition. If server has enough RAM memory and PROCESSOR memory, returns true, otherwise, returns false.* |  **int** *_operation*: operation required by incoming petition. |
| AssignValues(***int*** *_operation*, ***string*** *_id*, ***Cola*** *_memory*, ***Cola*** *_procesor*) | *If server has accepted the petition, then it requires the values of the petition. This method receives two queues with RAM values and PROCESSOR values in order to save these values on its RAM memory and PROCESSOR memory.*|  **int** *_operation*: operation required by incoming petition.   **string** *_id*: unique name generated by SERVIS for every petition.  **Cola** *_memory*: RAM values of petitions.  **Cola** *_processor*: Processor values of petitions. |
| Operate() | *Indicates server to operate the values of petitions received.* | ***none*** |


### BalanceadorDeCarga

> This is the main tool to operate as many petitions as possible. First, it has the main access: to HardDrive, to 'Unsuccessful Petitions' queue, to 'Successful Petitions' queue, and to original queue of petitions. Also has the Log queue, in which SERVIS saves all operations status.This class is responsible of prepare the petitions before servers can accept them.

| Function or Method | Description | Parameter |
| :-------: | :------: | :----- |
|Allocator(**int** *_operations*, **string** *_id*)| *Decides what servers is properly to handle every petition. This call `bool Servers::AcceptPetition(int _operation)` function.*|**int** *_operation*: operation required by incoming petition. **string** *_id*: unique name generated by SERVIS for every petition.  |
|Split() & Values()| *Values come in from .txt files as a string format, due that, these functions split the string and sort it into numeric values, ready to use by SERVIS.*| ***none***|
| Operate()| *Analyzes and determines the specific order in which servers should start operating. Also indicates to computer when it must stop the program.*| ***none*** |