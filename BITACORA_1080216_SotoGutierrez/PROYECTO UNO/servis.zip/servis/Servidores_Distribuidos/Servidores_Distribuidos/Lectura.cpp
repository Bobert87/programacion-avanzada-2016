#include "stdafx.h"
#include "Lectura.h"


vector<string> Lectura::Read() {

	try
	{
		x = 0;
		if (ifstream("servis.txt"))
		{
			File.open("servis.txt"); 
			while (getline(File, line)) 
			{
				if (line[0] != 47 && line != "") 
				{
					x = x + 1;
				}
			}
			if (x < 3)
			{
				cout << "\"servis.txt\" IS EMPTY - CAN NOT CONTINUE." << endl;
				cin.get();
				exit(0);
			}
			File.close(); // VERY IMPORTANT CLOSE THE FILE AFTER READ IT.
		}
		else
		{
			cout << "\"servis.txt\" IS NOT AVAILABLE - CAN NOT CONTINUE." << endl;
			cin.get();
			exit(0);
		}


		for (int i = 1; i < 10; i++)
		{
			string newFile = "thefile" + to_string(i) + ".txt";
			if (ifstream(newFile))
			{
				File.open(newFile); // WE NEED TO OPEN THE .TXT 
				while (getline(File, line)) // WHILE .TXT HAS MORE LINES, WE CONTINUE READING.
				{
					if (line[0] != 47 && line != "") // IS NOT A COMMENT, IS IT?
					{
						x = x + 1;
					}
				}
				File.close(); // VERY IMPORTANT CLOSE THE FILE AFTER READ IT.

			}
		}

		if (x != 0 && x % 3 == 0)
		{
			File.open("servis.txt"); // WE NEED TO OPEN THE .TXT 
			while (getline(File, line)) // WHILE .TXT HAS MORE LINES, WE CONTINUE READING.
			{
				if (line != "" && line[line.size() - 1] == 32)
				{
					line = line.substr(0, line.size() - 1);
				}
				if (line[0] != 47 && line != "") // IS NOT A COMMENT, IS IT?
				{
					Push(line);
				}
			}
			File.close(); // VERY IMPORTANT CLOSE THE FILE AFTER READ IT.

			for (int i = 1; i < 10; i++)
			{
				string newFile = "thefile" + to_string(i) + ".txt";
				if (ifstream(newFile))
				{
					File.open(newFile); // WE NEED TO OPEN THE .TXT 
					while (getline(File, line)) // WHILE .TXT HAS MORE LINES, WE CONTINUE READING.
					{
						if (line != "" && line[line.size() - 1] == 32)
						{
							line = line.substr(0, line.size() - 1);
						}
						if (line[0] != 47 && line != "") // IS NOT A COMMENT, IS IT?
						{
							Push(line);
						}
					}
					File.close(); // VERY IMPORTANT CLOSE THE FILE AFTER READ IT.

				}
			}
			return Lines;
		}
		else
		{
			cout << "FILES SEEMS NOT TO BE OK - NUMBER OF LINES IS NOT DIVISIBLE BY THREE (3) OR FILE IS EMPTY - CAN NOT CONTINUE.";
			exit(0);
		}

		
	}
	catch (const std::exception&)
	{
		cout << "FILES SEEMS NOT TO BE OK - NUMBER OF LINES IS NOT DIVISIBLE BY THREE (3) OR FILE IS EMPTY - CAN NOT CONTINUE.";
		cin.get();
		exit(0);
	}

}

bool Lectura::Push(string _line) {
	try
	{
		if (count < 3) // leyendo las primeras tres lineas? estas son las configuraciones de los servidores
		{
			string abc = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz!\"#$%&/()=?\\,.;:{}[]*-_+";
			for (int i = 0; i < _line.size(); i++)
			{
				for (int j = 0; j < abc.size(); j++)
				{
					if (_line[i] == abc[j]) // no deben contener letras ni caracteres
					{
						cout << "SERVERS PARAMETERS ARE NOT CORRECT. BE SURE TO INCLUDE ONLY INTEGERS IN VALUES." << endl;
						cin.get();
						exit(0);
					}
				}
			}
			this->Lines.push_back(_line); // estan limpios
			count++;
			return true;
		}
		else
		{
			if (count % 3 == 0) //  la linea es multiplo de tres? si si, solo guardamos, es una instruccion. Si no es valida, alguien la validar� luego
			{
				this->Lines.push_back(_line);
				count++;
				return true;
			}
			else // sino, es una valor, no debe tener ningun caracter, y tampoco deberia tener espacio vacio al final de la cadena o al principio.
			{
				string abc = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz!\"#$%&/()=?\\,.;:{}[]*_+";
				for (size_t i = 0; i < _line.size(); i++)
				{
					for (int j = 0; j < abc.size(); j++)
					{
						if (_line[i] == abc[j])
						{
							for (int k = count % 3; k > 0; k--)
							{
								Lines.pop_back();
							}
							count = count - count % 3;
							cout << "PETITION DENIED DUE TO INCORRECT VALUES IN LINE: " + to_string(count) << endl;
							cin.get();
							return false;
						}
					}
				}
				this->Lines.push_back(_line);
				count++;
				return true;
			}
		}
		return true;
	}
	catch (const std::exception&)
	{
		cout << "PETITION DENIED. BE SURE PETITIONS HAVE THE CORRECT FORMAT OR SEE THE MANUAL FOR MORE INFORMATION." << endl;
		cin.get();
		exit(0);
	}
}

bool Lectura::Save(vector<string> *success, vector<string> *unsuccess) {
	try
	{
		ofstream results; // crearemos un archivo llamado results y lo limpia.
		results.open("results.txt");
		results.clear();
		//guarda todos los datos de la cola de peticiones, fallida y exitosa, y luego cierra el archivo.
		for (int i = 0; i < success->size(); i++)
		{
			results << success->at(i);
		}
		for (int i = 0; i < unsuccess->size(); i++)
		{
			results << unsuccess->at(i);
		}
		results.close();
		return true;
	}
	catch (const std::exception&)
	{
		cout << "AN ERROR OCCURED WHILE SAVING THE RESULTS" << endl;
		cin.get();
		exit(0);
	}
}