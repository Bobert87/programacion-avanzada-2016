// Servidores_Distribuidos.cpp: define el punto de entrada de la aplicaci�n de consola.
//
#include "stdafx.h"
#include "BalanceadorDeCarga.h"

int main()
{

	BalanceadorDeCarga Objeto;
	
	cout << "\n\n\t\tStart SERVIS? Press any key to continue..." << endl;
	cin.get();
	
	
	Objeto.ServerBuilder();

	while (Objeto.Start())
	{
		Objeto.Start();
	}

	Objeto.WriteResults();
	system("PAUSE");
	return 0;

}



