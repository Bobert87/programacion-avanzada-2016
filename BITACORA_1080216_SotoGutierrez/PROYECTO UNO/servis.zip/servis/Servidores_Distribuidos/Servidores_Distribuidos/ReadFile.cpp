#include "stdafx.h"
#include <string>
#include <windows.h>
#include <iostream>
class ReadFile
{
public:
	
	bool Read() {
		fopen("prueba.txt","r");
	}


private:





};


