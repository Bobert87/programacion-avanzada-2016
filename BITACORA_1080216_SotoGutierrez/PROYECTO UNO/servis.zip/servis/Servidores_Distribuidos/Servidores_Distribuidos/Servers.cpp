#include "stdafx.h"
#include "Servers.h"
#include "HardDrive.h"
#include <string>
#include "Cola.h"
Servers::Servers(int _ram, int _processor, int _operations, string _name, HardDrive *_drive, vector<string> *_successful, vector<string> *_log)
{
	// constructor por defecto.
	try
	{
		Operations = _operations;
		Petitions = _operations;
		Ram = _ram;
		Process = _processor;
		Drive = _drive;
		Successful = _successful;
		Name = _name;
		Log = _log;
	}
	catch (const std::exception&)
	{
		cout << "AN ERROR OCCURRED WHILE CREATING SERVERS" << endl;
		cin.get();
		exit(0);
	}
}

bool Servers::IsNotEmpty() {
	try
	{
		if (this->Memory->Count() > 0 || this->Processor->Count() > 0) // hay datos en la memoria? Signifca que hay peticiones pendientes o de lo contrario ser�a un error
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	catch (const std::exception&)
	{
		cout << "AN ERROR OCCURED IN: IsNotEmpty(). MAYBE THE VALUES WERE NOT CORRECT?" << endl;
		cin.get();
		exit(0);
	}
}

bool Servers::IsUsed() {
	return this->Used;
}

int Servers::Movements() {
	try
	{
		if (this->HardDrivePosition() == 0) // define la cantidad de movimientos minima que el servidore requiere para mover el disco
		{
			return 0;
		}
		else
		{
			int Drive1 = Drive->Position();
			int Drive2 = Drive->Position();
			int x = 0;
			int y = 0;

			for (int i = 0; i < 5; i++) //anilizando hacia adelante
			{
				if (Drive1 + i > 5)
				{
					Drive1 = 0;
				}
				if (Drive1 + i == this->HardDrivePosition())
				{
					x = i;
					break;
				}
			}
			for (int j = 0; j < 5; j++) // anilizando hacia atras.
			{
				if (Drive2 - j < 1)
				{
					Drive2 = 6;
				}
				if (Drive2 - j == this->HardDrivePosition())
				{
					y = j;
					break;
				}
			}
			if (x < y)
			{
				return x;
			}
			else if (x == y)
			{
				return x;
			}
			else
			{
				return y;
			}
		}
	}
	catch (const std::exception&)
	{
		cout << "AN ERROR OCCURRED IN Movements(). MAYBE THE POSITION REQUIRED WERE NOT CORRECT?" << endl;
		cin.get();
		exit(0);
	}
}

int Servers::HardDrivePosition() {
	if (this->IsNotEmpty()) {
		switch (PetitionsQueue->Front())
		{
		case 0: // segun cada operacion, esta necesita una posicion de disco duro especifica
			return 3;
			break;
		case 1:
			return 5;
			break;
		case 2:
			return 1;
			break;
		case 3:
			return 4;
			break;
		case 4:
			return 2;
			break;
		default:
			return 0;
			break;
		}
	}
	else
	{
		return 0;
	}
}

int Servers::ValuesInProcessorOfFirstPetitionInQueue() {
	try
	{
		int _petitions = this->PetitionsQueue->Count(); // este metodo analiza cuantos enteros de la actual peticion existen aun en el procesador.
		int TotalValues = 0;
		int FirstPetitionValues = 0;

		switch (this->PetitionsQueue->Front()) // cuantos datos deber�a tener la actual peticion
		{
		case 0:
			FirstPetitionValues = 5;
			break;
		case 1:
			FirstPetitionValues = 3;
			break;
		case 2:
			FirstPetitionValues = 3;
			break;
		case 3:
			FirstPetitionValues = 5;
			break;
		case 4:
			FirstPetitionValues = 2;
			break;
		default:
			FirstPetitionValues = 0;
			break;
		}
		for (int i = 0; i < _petitions; i++) // cuantos datos deber�n haber segun las operaciones que el servidor tenga como recibidas
		{
			switch (this->PetitionsQueue->ValueAtIndex(i))
			{
			case 0:
				TotalValues += 5;
				break;
			case 1:
				TotalValues += 3;
				break;
			case 2:
				TotalValues += 3;
				break;
			case 3:
				TotalValues += 5;
				break;
			case 4:
				TotalValues += 2;
				break;
			default:
				TotalValues += 0;
				break;
			}
		}

		return this->Processor->Count() - (TotalValues - FirstPetitionValues); // retorna el numero de datos que pertenecen solo a la primera operacion .
	}
	catch (const std::exception&)
	{
		cout << "AN ERROR OCCURED IN ValuesInProcessorOfFirstPetitionInQueue(). MAYBE VALUES WERE NOT CORRECTLY SAVED ON SERVER?" << endl;
		cin.get();
		exit(0);
	}
}

bool Servers::SubstractPetitions(int Used) {
	//ESTE METODO RESTA UNA PETICION DEL TOTAL DE PETICIONES DISPONIBLES EN EL SERVIDOR.
	this->Petitions = this->Petitions - Used;
	return true;
}

bool Servers::MemoryQueue(int _value) {
	try
	{
		Memory->Queue(_value);
		return true;
		
	}
	catch (const std::exception&)
	{
		return false;
	}
}

bool Servers::MemoryDequeue() {
	try
	{
		Memory->Dequeue();
		return true;
	}
	catch (const std::exception&)
	{
		return false;
	}
}

bool Servers::ProcessorQueue(int _value) {
	try
	{
		Processor->Queue(_value);
		return true;
	}
	catch (const std::exception&)
	{
		return false;
	}
}

int Servers::ProcessorDequeue() {
	try
	{
		if (Petitions > 0)
		{
			
			this->SubstractPetitions(1);
			return Processor->Dequeue();
		}
		else
		{
			return -1;
		}
	}
	catch (const std::exception&)
	{
		return -1;
	}
}

bool Servers::AssignValues(int _operation, string _id, string _values, Cola _processor, Cola _memory) {
	try // si el servidor acepta una  peticion, este metodo recibe todos los datos y los guarda en el servidor donde corresponden.
	{
		this->PetitionsQueue->Queue(_operation);
		this->PetitionsID->push_back(_id);
		this->PetitionsValues->push_back(_values);
		this->Used = true;
		string ram = "";
		string processor = "";
		switch (_operation)
		{ // para cada tipo de operacion se asigna un numero de datos especifico.
		case 0: // SUM - Ram = 3, Processor = 5;
			for (int i = 0; i < 5; i++)
			{
				if (i < 3)
				{
					this->MemoryQueue(_memory.Front());
					ram += to_string(_memory.Dequeue()) + " ";
				}
				this->ProcessorQueue(_processor.Front());
				processor += to_string(_processor.Dequeue()) + " ";
			}
			break;
		case 1: // SUB - Ram = 4, Processor = 3;
			for (int i = 0; i < 4; i++)
			{
				if (i < 3)
				{
					this->ProcessorQueue(_processor.Front());
					processor += to_string(_processor.Dequeue()) + " ";
				}
				this->MemoryQueue(_memory.Front());
				ram += to_string(_memory.Dequeue()) + " ";
			}
			break;
		case 2: // MUL - Ram = 6, Processor = 3;
			for (int i = 0; i < 6; i++)
			{
				if (i < 3)
				{
					this->ProcessorQueue(_processor.Front());
					processor += to_string(_processor.Dequeue()) + " ";
				}
				this->MemoryQueue(_memory.Front());
				ram += to_string(_memory.Dequeue()) + " ";
			}
			break;
		case 3: // DIV - Ram = 5, Processor = 5;
			for (int i = 0; i < 5; i++)
			{
				this->ProcessorQueue(_processor.Front());
				processor += to_string(_processor.Dequeue()) + " ";
				this->MemoryQueue(_memory.Front());
				ram += to_string(_memory.Dequeue()) + " ";

			}
			break;
		case 4: // NEG - Ram = 1, Processor = 2;
			for (int i = 0; i < 2; i++)
			{
				if (i < 1)
				{
					this->MemoryQueue(_memory.Front());
					ram += to_string(_memory.Dequeue()) + " ";
				}
				this->ProcessorQueue(_processor.Front());
				processor += to_string(_processor.Dequeue()) + " ";
			}
			break;
		default:
			return false;
			break;
		}

		this->Log->push_back("PETITION RECEIVED : " + this->NameOfPetition(_operation) + "\nID: " + _id + "\nSEVER: " + this->Name + +"\nRAM AVAILABLE: " + to_string(this->Ram - this->Memory->Count()) + "\nPROCESSOR AVAILABLE: " + to_string(this->Process - this->Processor->Count()) + "\nRAM VALUES: " + ram + "\nPROCESSOR VALUES: " + processor);
		return true;
	}
	catch (const std::exception&)
	{
		cout << "AN ERROR OCCURRED SAVING THE VALUES. BE SURE VALUES HAVE CORRECT FORMAT ON TXT FILE OR SEE MANUAL." << endl;
		cin.get();
		exit(0);
	}
}

bool  Servers::AcceptPetition(int _operation) {
	try
	{ // analiza si la peticion entrante puede almacenarse en la memoria ram y el procesador del servidor.
		string msg = "INCOMING PETITION TO: " + this->Name + "\nRAM AVAILABLE: " + to_string(this->Ram - this->Memory->Count()) + "\nPROCESSOR AVAILABLE: " + to_string(this->Process - this->Processor->Count());
		switch (_operation)
		{
		case 0: // SUM - Ram = 3, Processor = 5;
			this->Log->push_back(msg + "\nOPERATION:" + this->NameOfPetition(_operation) + "\nRAM required: 3 \nPROCESSOR required: 5");
			if (((Memory->Count() + 3) <= this->Ram) && (((Processor->Count() + 5)) <= this->Process))
			{
				return true;
			}
			else
			{
				this->Log->push_back(" -> INCOMING PETITION REFUSED BY: " + this->Name);
				return false;
			}
			break;
		case 1: // SUB - Ram = 4, Processor = 3;
			this->Log->push_back(msg + "\nOPERATION:" + this->NameOfPetition(_operation) + "\nRAM required: 4\nPROCESSOR required: 3");
			if (((Memory->Count() + 4) <= this->Ram) && (((Processor->Count() + 3)) <= this->Process))
			{
				return true;
			}
			else
			{
				this->Log->push_back(" -> INCOMING PETITION REFUSED BY: " + this->Name);
				return false;
			}
			break;
		case 2: // MUL - Ram = 6, Processor = 3;
			this->Log->push_back(msg + "\nOPERATION:" + this->NameOfPetition(_operation) + "\nRAM required: 6\nPROCESSOR required: 3");
			if (((Memory->Count() + 6) <= this->Ram) && (((Processor->Count() + 3)) <= this->Process))
			{
				return true;
			}
			else
			{
				this->Log->push_back(" -> INCOMING PETITION REFUSED BY: " + this->Name);
				return false;
			}
			break;
		case 3: // DIV - Ram = 5, Processor = 5;
			this->Log->push_back(msg + "\nOPERATION:" + this->NameOfPetition(_operation) + "\nRAM required: 5\nPROCESSOR required: 5");
			if (((Memory->Count() + 5) <= this->Ram) && (((Processor->Count() + 5)) <= this->Process))
			{
				return true;
			}
			else
			{
				this->Log->push_back(" -> INCOMING PETITION REFUSED BY: " + this->Name);
				return false;
			}
			break;
		case 4: // DIV - Ram = 1, Processor = 2;
			this->Log->push_back(msg + "\nOPERATION:" + this->NameOfPetition(_operation) + "\nRAM required: 1\nPROCESSOR required: 2");
			if (((Memory->Count() + 1) <= this->Ram) && (((Processor->Count() + 2)) <= this->Process))
			{
				return true;
			}
			else
			{
				this->Log->push_back(" -> INCOMING PETITION REFUSED BY: " + this->Name);
				return false;
			}
			break;
		default:

			return false;
			break;
		}
	}
	catch (const std::exception&)
	{
		cout << "AN ERROR OCCURRED ACCEPTING THE VALUES BY SERVER. MAYBE THE SERVERS FAILED OR THE LOG IS NOT CORRECT?" << endl;
		cin.get();
		exit(0);
	}
}

int Servers::OperateMemory() {
	try
	{	// extrae la memoria ram de la peticion y la opera, segun la peticion entrante.
		int Result = 0; 
		switch (this->PetitionsQueue->Front())
		{
		case 0:
			for (int i = 0; i < 3; i++)
			{
				Result += this->Memory->Front();
				this->MemoryDequeue();
			}
			break;
		case 1:
			for (int i = 0; i < 4; i++)
			{
				Result -= this->Memory->Front();
				this->MemoryDequeue();
			}
			break;
		case 2:
			for (int i = 0; i < 5; i++)
			{
				Result += this->Memory->Front();
				this->MemoryDequeue();
			}
			Result += this->Memory->Front();
			Result *= this->Memory->Front();
			this->MemoryDequeue();
			break;
		case 3:
			for (int i = 0; i < 4; i++)
			{
				Result += this->Memory->Front();
				this->MemoryDequeue();
			}
			Result /= this->Memory->Front();
			this->MemoryDequeue();
			break;
		case 4:
			Result = this->Memory->Front() * (-1);
			this->MemoryDequeue();
			break;
		default:
			return 0;
			break;
		}

		return Result;
	}
	catch (const std::exception&)
	{
		cout << "AN ERROR OCCURRED WHILE OPERATING THE RAM MEMORY. SEE COLA CLASS?" << endl;
		cin.get();
		exit(0);
	}
}

string Servers::ToSuccessful() {
	try
	{
		string Operation = this->NameOfPetition(this->PetitionsQueue->Front());
		string x = to_string(this->OperateMemory());
		this->Successful->push_back("SUCCESSFUL PETITION: " + Operation + "\nID: " + this->PetitionsID->front() + "\nValues: "+ this->PetitionsValues->front() + "\nResult: " + x + "\n");
		return x;
	}
	catch (const std::exception&)
	{
		cout << "AN ERROR OCCURRED WHILE SAVING THE RESULT OF A SUCCESFUL PETITION. MAYBE SUCCCESSFUL QUEUE IS FAILING?" << endl;
		cin.get();
		exit(0);
	}
}

bool Servers::Operate() {
	try
	{
		this->Petitions = this->Operations;
		this->Used = false;
		if (this->IsNotEmpty()) // el servidor aun tiene peticiones pendientes?
		{
			int Actual = this->PetitionsQueue->Front(); // que peticion es la primera en cola?
			this->Log->push_back(" -> Trying to operate on " + this->Name + " petition: " + this->NameOfPetition(this->PetitionsQueue->Front()) + " with ID: " + this->PetitionsID->front());
			this->Log->push_back(" -> Operations available: " + to_string(this->Petitions));
			if (this->Petitions > this->Movements()) // Las peticiones disponibles son m�s que las necesarias para mover el disco?
			{
				this->Log->push_back(" -> HardDrive actual position: " + to_string(this->Drive->Position()));
				this->Log->push_back(" -> HardDrive position needed: " + to_string(this->HardDrivePosition()));
				this->SubstractPetitions(this->Movements()); 
				this->Drive->Move(this->HardDrivePosition()); // mueve el disco
				this->Log->push_back(" -> Hard Drive moved to position: " + to_string(this->HardDrivePosition()));
			}
			while (true)
			{
				if (Actual == this->PetitionsQueue->Front()) // mientras la peticion no haya sido operada
				{
					if (this->Petitions > 0 && this->IsNotEmpty()) // mientras existan operaciones disponibles y aun exista peticiones en cola
					{
						if (ValuesInProcessorOfFirstPetitionInQueue() != 0) // sacamos la cantidad de enteros que pertenecen a la peticion actual.
						{
							int x = this->ProcessorDequeue(); // quitamos un dato del procesador.
							this->Log->push_back(" -> Operated value: " + to_string(x));
						}
						else
						{	// ya no hay datos de la peticion que operar, entonces generamos el resultado 
							string result = this->ToSuccessful();
							this->SubstractPetitions(1);
							this->Log->push_back(" -> Petition completed: \n\tOperation: " + this->NameOfPetition(this->PetitionsQueue->Front()) + "\n\tID: " + this->PetitionsID->front() + "\n\tResult: " + result);
							this->PetitionsQueue->Dequeue(); //�sacamos la peticion pues ya fue completada
							this->PetitionsID->erase(PetitionsID->begin()); // tambien el id, pues es paralelo a la peticion.
							this->PetitionsValues->erase(PetitionsValues->begin()); // lo mismo para los values.
							if (this->PetitionsQueue->Count() == 0) // no hay mas operaciones en el servidor?
							{
								this->Log->push_back("\t!!! ALL PETITIONS IN SERVER COMPLETED !!!");
								return true;
							}
						}
						this->Log->push_back(" -> Operations still available: " + to_string(this->Petitions)); // aun existen mas operaciones
					}
					else
					{
						if (this->Petitions > 0) // en un mismo tick, la operacion cambio, pero todas las peticiones se completaron en el mismo tick y aun hay mas operaciones disponibles
						{
							this->Log->push_back("\t!!! ALL PETITIONS IN SERVER COMPLETED !!!");
						}
						else
						{
							this->Log->push_back("\tSERVER RUNS OUT OF AVAILABLE PETITIONS"); // la otra variante es que no hayan mas operaciones, entonces el servidor no puede serguir operando
						}
						return true;
					}
				}
				else // la peticion cambio, puede que se haya completado la anterior o cambio por algun motivo
				{
					Actual = this->PetitionsQueue->Front(); // cambiamos la operacion actual 
					this->Log->push_back(" -> Trying to operate on " + this->Name + " petition: " + this->NameOfPetition(this->PetitionsQueue->Front()) + " ID: " + this->PetitionsID->front());
					this->Log->push_back(" -> Operations available: " + to_string(this->Petitions));
					if (this->Petitions > this->Movements()) // Operaciones disponibles mayor al numero de operaciones necesarias para mover el disco?
					{
						this->Log->push_back(" -> HardDrive actual position: " + to_string(this->Drive->Position()));
						this->Log->push_back(" -> HardDrive position needed: " + to_string(this->HardDrivePosition()));
						this->SubstractPetitions(this->Movements());
						this->Drive->Move(this->HardDrivePosition()); // mueve el disco.
						this->Log->push_back(" -> HardDrive moved to position: " + to_string(this->HardDrivePosition()));
					}
					else
					{
						this->Log->push_back("\tSERVER RUNS OUT OF AVAILABLE PETITIONS"); // sino, el servidor ya no tiene peticiones disponibles.
						return true;
					}
				}
			}
		}
		else
		{
			return false;
		}
	}
	catch (const std::exception&)
	{
		cout << "AN ERROR OCCURRED TRYING TO SEND OPERATE COMMAND TO SERVERS" << endl;
		cin.get();
		exit(0);
	}
}

string Servers::NameOfPetition(int x) {
	try
	{
		switch (x)
		{
		case 0:
			return "SUM";
			break;
		case 1:
			return "SUB";
			break;
		case 2:
			return "MUL";
			break;
		case 3:
			return "DIV";
			break;
		case 4:
			return "NEG";
			break;
		default:
			return "NULL";
			break;
		}
	}
	catch (const std::exception&)
	{
		cout << "AN ERROR OCCURRED TRYING TO NAME AN OPERATION " << endl;
		cin.get();
		exit(0);
	}
}

Servers::~Servers()
{
}


