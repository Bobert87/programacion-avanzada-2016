#pragma once
#include "stdafx.h"
#include <iostream>
#include <fstream>
#include <string>
#include <vector>

using namespace std;

class Lectura
{
public:

	vector<string> Read();
	bool Push(string _line);
	bool Save(vector<string> *success, vector<string> *unsuccess);
private:

	ifstream File; // THIS IS THE OBJECT THAT WILL OPEN THE .TXT
	string line; // THIS IS THE OBJECT THAT WILL SAVE THE STRING OF A LINE WHILE READING THE FILE. 
	int count = 0;
	int x = 0;
	vector<string> Lines;

};
