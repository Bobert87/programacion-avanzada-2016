#pragma once
#include "stdafx.h"
#include <vector>
#include <iostream>
#include "Servers.h"
#include "Lectura.h"
#include "HardDrive.h"

using namespace std;


class BalanceadorDeCarga
{
public:
	BalanceadorDeCarga();
	~BalanceadorDeCarga();


	// METHODS
	
	
	bool Start();
	void ServerBuilder();
	void WriteResults();
	
private:

	// METHODS
	Cola Split(string texto);
	Cola Values();
	bool Operate();
	bool Allocator();
	bool Allocator(int _operation, string _id);
	string ID();
	void ToUnsuccessful(int _petition, string _id, string values);
	bool PetitionsIsValid(int _petition, Cola value_ram, Cola value_processor);

	//VARIABLES
	vector<string> Lines;
	Servers *ServidorUno;
	Servers *ServidorDos;
	Servers *ServidorTres;
	HardDrive *Drive = new HardDrive();
	vector<string> *Successful = new vector<string>;
	vector<string> *Unsuccessful = new vector<string>;
	vector<string> *Log = new vector<string>;
};
