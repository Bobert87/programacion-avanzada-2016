#include "stdafx.h"
#include "BalanceadorDeCarga.h"
#include <iostream>
#include "Lectura.h"
#include <conio.h>


BalanceadorDeCarga::BalanceadorDeCarga()
{
}

BalanceadorDeCarga::~BalanceadorDeCarga()
{
}

Cola BalanceadorDeCarga::Split(string text) {
	try
	{
		Cola sections;  // Cola auxiliar usada para almanecar temporalmente los valores.
		int x = 0; // variable utilizada para cortar la cadena en el punto correcto
		int length = text.size(); 
		if (length != 1)
		{
			for (int i = 0; i < length; i++)
			{
				if (text[i] == 32) // el caracterer de la cadena en posicion i es igual a un espacio ?
				{
					sections.Queue(stoi(text.substr(x, i))); // corta la cadena dejando solo los interos.
					x = i + 1;
				}
			}
			sections.Queue(stoi(text.substr(x, length - 1))); //el ultimo dato debe ser cortado  tambien.
		}
		else
		{
			sections.Queue(stoi(text)); //si la cadena tiene solo un caracter , nada mas lo convertimos a int.
		}
		return sections;
	}
	catch (const std::exception&)
	{
		cout << "AN ERROR OCCURRED TRYING TO SPLIT A STRING. BE SURE TXT FILES DO NOT HAVE BLANK SPACES OR LINES." << endl;
		cin.get();
		exit(0);
	}
}

Cola BalanceadorDeCarga::Values() {
	try
	{
		Cola ListOfValues;
		ListOfValues = Split(Lines[0]); // Toma y divide la cadena en la lista de peticiones
		Lines.erase(Lines.begin()); // borra esa cadena y entonces la siguiente esta lista para ser usada.
		return ListOfValues;
	}
	catch (const std::exception&)
	{
		cout << "AN ERROR OCCURRED TRYING TO GET THE VALUES ON INT FORMAT" << endl;
		cin.get();
		exit(0);
	}
}

string BalanceadorDeCarga::ID() {
	
	// generador de valores random

	char cadena[36] = { 'A','B','C','D','E','F','G','H','I','J','K','L',
						'M','N','O','P','Q','R','S','T','U','V','W','X',
						'Y','Z','0','1','2','3','4','5','6','7','8','9' };

	string id = "";
	for (int i = 0; i < 5; i++)
	{
		id = id + cadena[rand() % 35];
	}

	return id;
	
}

void BalanceadorDeCarga::ServerBuilder() {

	Lectura Lector; // Todo comienza inicializando los servidores
	Lines = Lector.Read(); // Leemos toda la informacion
	Cola Specs; // Cola auxiliar para guardar la informaci�n de los servidores

	Specs = Split(Lines[0]); // Extraemos los datos del primer servidors
	if (Specs.ValueAtIndex(0) > 0 && Specs.ValueAtIndex(1) > 1 && Specs.ValueAtIndex(2) > 1) // los valores son correctos?
	{
		ServidorUno = new Servers(Specs.ValueAtIndex(0), Specs.ValueAtIndex(1), Specs.ValueAtIndex(2), "SERVIDOR 1", Drive, Successful, Log); // genera el servidor
		this->Log->push_back("Server created: SERVIDOR 1 \nRAM: " + to_string(Specs.ValueAtIndex(0)) + "\nPROCESSOR: " + to_string(Specs.ValueAtIndex(1)) + "\nMAX OPERATIONS PER TICK: " + to_string(Specs.ValueAtIndex(2)));
		Lines.erase(Lines.begin()); // borramos la linea de la cola de peticiones pues ya no se necesita.
	}
	else
	{
		cout << "AN ERROR OCCURRED BUILDING THE SERVERS. VALUES ARE NEGATIVE OR ZERO. SEE MANUAL FOR MORE INFORMATION." << endl;
		cin.get();
		exit(0);
	}
	Specs = Split(Lines[0]);
	if (Specs.ValueAtIndex(0) > 0 && Specs.ValueAtIndex(1) > 1 && Specs.ValueAtIndex(2) > 1)
	{
		ServidorDos = new Servers(Specs.ValueAtIndex(0), Specs.ValueAtIndex(1), Specs.ValueAtIndex(2), "SERVIDOR 2", Drive, Successful, Log);
		this->Log->push_back("Server created: SERVIDOR 2 \nRAM: " + to_string(Specs.ValueAtIndex(0)) + "\nPROCESSOR: " + to_string(Specs.ValueAtIndex(1)) + "\nMAX OPERATIONS PER TICK: " + to_string(Specs.ValueAtIndex(2)));
		Lines.erase(Lines.begin());
	}
	else
	{
		cout << "AN ERROR OCCURRED BUILDING THE SERVERS. VALUES ARE NEGATIVE OR ZERO. SEE MANUAL FOR MORE INFORMATION." << endl;
		cin.get();
		exit(0);
	}
	Specs = Split(Lines[0]);
	if (Specs.ValueAtIndex(0) > 0 && Specs.ValueAtIndex(1) > 1 && Specs.ValueAtIndex(2) > 1)
	{
		ServidorTres = new Servers(Specs.ValueAtIndex(0), Specs.ValueAtIndex(1), Specs.ValueAtIndex(2), "SERVIDOR 3", Drive, Successful, Log);
		this->Log->push_back("Server created: SERVIDOR 3 \nRAM: " + to_string(Specs.ValueAtIndex(0)) + "\nPROCESSOR: " + to_string(Specs.ValueAtIndex(1)) + "\nMAX OPERATIONS PER TICK: " + to_string(Specs.ValueAtIndex(2)));
		Lines.erase(Lines.begin());
	}
	else
	{
		cout << "AN ERROR OCCURRED BUILDING THE SERVERS. VALUES ARE NEGATIVE OR ZERO. SEE MANUAL FOR MORE INFORMATION." << endl;
		cin.get();
		exit(0);
	}
	this->Log->push_back("out");
}

void BalanceadorDeCarga::WriteResults() {
	try
	{
		for (int i = 0; i < this->Log->size(); i++) //recorremos el LOG
		{
			if (Log->at(i) == "out") // la linea es igual a out? limpia la consola.
			{
				system("cls");
				continue; // pasa a la siguiente linea de LOG
			}
			cout << Log->at(i) << endl; // Imprime linea por linea
			cout << "\n" << endl;
			if (char c = _getch()) // el usuario quiere ver el resumen en lugar de recorrer todo el log?
			{
				if (c == 27) // si
				{
					break;
				}
				else //no
				{
					continue;
				}
			}
		}
		Lectura Write;
		Write.Save(this->Successful, this->Unsuccessful); // escribe el resumen en un archivo de texto
		system("notepad.exe results.txt"); //abre el archivo en notepad.exe
	}
	catch (const std::exception&)
	{
		cout << "AN ERROR OCCURRED WRITING THE RESULTS. MAYBE THE ARRAYS ARE EMPTY OR OUT OF RANGE?" << endl;
		cin.get();
		exit(0);
	}
}

bool BalanceadorDeCarga::Allocator() {
	try
	{
		string IncomingOperation = Lines[0]; //leemos la instruccion entrante
		Lines.erase(Lines.begin()); // la borramos pues ya no se usara, o es fallida o se opera
		string _id = ID(); // generamos el ID.
		// debemos establecer un identificador numerico para cada peticion pues es mas eficiente y rapido
		if (IncomingOperation == "SUM") 
		{
			this->Allocator(0, _id); // sum = 0
		}
		else if (IncomingOperation == "SUB")
		{
			this->Allocator(1, _id); // sub = 1
		}
		else if (IncomingOperation == "MUL")
		{
			this->Allocator(2, _id); // mul = 2
		}
		else if (IncomingOperation == "DIV")
		{
			this->Allocator(3, _id); // div = 3
		}
		else if (IncomingOperation == "NEG")
		{
			this->Allocator(4, _id); // neg = 4
		}
		else
		{
			this->Log->push_back("\t\t ---> ERROR : Petition has NOT been understood: " + IncomingOperation); // la peticion recibida no es ninguna de las 5 anteriores
			Lines.erase(Lines.begin()); // borramos los 2 datos que contenia
			Lines.erase(Lines.begin()); //
			return false;
		}
		return true;
	}
	catch (const std::exception&)
	{
		cout << "AN ERROR OCCURRED WITH INCOMMING PETITION. MAYBE IT IS NOT CORRECT?" << endl;
		cin.get();
		exit(0);
	}
}

bool BalanceadorDeCarga::Allocator(int _operation, string _id) {

	try
	{
		string _values = Lines.front() + " ; ";
		Cola values_processor = Values(); // una vez definida la peticion entrante (metodo anterior), extraemos sus datos
		_values += Lines.front();
		Cola values_ram = Values();

		if (PetitionsIsValid(_operation, values_processor, values_ram)) // verificamos que la peticion entrante sea valida segun la operacion que requiera.
		{
			if (!ServidorUno->IsUsed() && ServidorUno->AcceptPetition(_operation)) //verificamos que cada servidor acepete una peticion por tick
			{
				ServidorUno->AssignValues(_operation, _id, _values, values_processor, values_ram);

			}
			else if (!ServidorDos->IsUsed() && ServidorDos->AcceptPetition(_operation))
			{
				ServidorDos->AssignValues(_operation, _id, _values, values_processor, values_ram);
			}
			else if (!ServidorTres->IsUsed() && ServidorTres->AcceptPetition(_operation))
			{
				ServidorTres->AssignValues(_operation, _id, _values, values_processor, values_ram);
			}
			else // pero si los servidores libres por tick no pueden aceptar la peticion, entonces consultamos con todos sin importar si ya han aceptado otra peticion anterios
			{
				if (ServidorUno->AcceptPetition(_operation))
				{
					ServidorUno->AssignValues(_operation, _id, _values, values_processor, values_ram);
				}
				else if (ServidorDos->AcceptPetition(_operation))
				{
					ServidorDos->AssignValues(_operation, _id, _values, values_processor, values_ram);
				}
				else if (ServidorTres->AcceptPetition(_operation))
				{
					ServidorTres->AssignValues(_operation, _id, _values, values_processor, values_ram);
				}
				else
				{
					this->ToUnsuccessful(_operation, _id, _values);
				}
			}
			return true;
		}
		else
		{
			this->ToUnsuccessful(_operation, _id, _values);
		}
	}
	catch (const std::exception&)
	{
		cout << "AN ERROR OCCURRED GETTING OR SETTING THE PETITION. MAYBE VALUES ARE NOT CORRECT?" << endl;
		cin.get();
		exit(0);
	}
}

bool BalanceadorDeCarga::PetitionsIsValid(int _operation, Cola value_processor, Cola value_ram) {
	switch (_operation) // segun cada operacion, esta requiere una cantidad de datos para ram y procesador
	{
	case 0:
		return (value_processor.Count() == 5 && value_ram.Count() == 3) ? true : false;
		break;
	case 1:
		return (value_processor.Count() == 3 && value_ram.Count() == 4) ? true : false;
		break;
	case 2:
		return (value_processor.Count() == 3 && value_ram.Count() == 6) ? true : false;
		break;
	case 3:
		return (value_processor.Count() == 5 && value_ram.Count() == 5) ? true : false;
		break;
	case 4:
		return (value_processor.Count() == 2 && value_ram.Count() == 1) ? true : false;
		break;
	}
}

bool BalanceadorDeCarga::Operate() {
	try
	{
		//guardamos  el numero  de movimientos que cada servidor necesita para tener el disco duro en la posicion requerida
		int ServerOne = ServidorUno->Movements();
		int ServerTwo = ServidorDos->Movements();
		int ServerThree = ServidorTres->Movements();
		// verificamos si el servidor tiene operaciones pendientes
		bool One = ServidorUno->IsNotEmpty();
		bool Two = ServidorDos->IsNotEmpty();
		bool Three = ServidorTres->IsNotEmpty();
		//validamos que servidor debe realizar menos operaciones para mover el disco

		if (ServerOne < ServerTwo && ServerOne < ServerThree)
		{
			if (One)
			{
				ServidorUno->Operate();
			}
			ServerTwo = ServidorDos->Movements();
			ServerThree = ServidorTres->Movements();

			if (ServerTwo < ServerThree)
			{
				if (Two)
				{
					ServidorDos->Operate();
				}
				if (Three)
				{
					ServidorTres->Operate();
				}
			}
			else
			{

				if (Three)
				{
					ServidorTres->Operate();
				}
				if (Two)
				{
					ServidorDos->Operate();
				}
			}

		}
		else if (ServerTwo < ServerOne && ServerTwo < ServerThree)
		{
			if (Two)
			{
				ServidorDos->Operate();
			}
			ServerOne = ServidorUno->Movements();
			ServerThree = ServidorTres->Movements();

			if (ServerOne < ServerThree)
			{
				if (One)
				{
					ServidorUno->Operate();
				}
				if (Three)
				{
					ServidorTres->Operate();
				}
			}
			else
			{
				if (Three)
				{
					ServidorTres->Operate();
				}
				if (One)
				{
					ServidorUno->Operate();
				}
			}
		}
		else if (ServerThree < ServerOne && ServerThree < ServerTwo)
		{
			if (Three)
			{
				ServidorTres->Operate();
			}
			ServerOne = ServidorUno->Movements();
			ServerTwo = ServidorDos->Movements();

			if (ServerOne < ServerTwo)
			{
				if (One)
				{
					ServidorUno->Operate();
				}
				if (Two)
				{
					ServidorDos->Operate();
				}
			}
			else
			{
				if (Two)
				{
					ServidorDos->Operate();
				}
				if (One)
				{
					ServidorUno->Operate();
				}
			}
		}
		else if (ServerOne == ServerTwo && ServerOne == ServerThree)
		{
			if (One)
			{
				ServidorUno->Operate();
			}
			ServerTwo = ServidorDos->Movements();
			ServerThree = ServidorTres->Movements();

			if (ServerTwo < ServerThree)
			{
				if (Two)
				{
					ServidorDos->Operate();
				}
				if (Three)
				{
					ServidorTres->Operate();
				}
			}
			else
			{
				if (Three)
				{
					ServidorTres->Operate();
				}
				if (Two)
				{
					ServidorDos->Operate();
				}
			}

		}
		else if (ServerOne == ServerTwo && ServerOne < ServerThree)
		{
			if (One)
			{
				ServidorUno->Operate();
			}
			ServerTwo = ServidorDos->Movements();
			ServerThree = ServidorTres->Movements();

			if (ServerTwo < ServerThree)
			{
				if (Two)
				{
					ServidorDos->Operate();
				}
				if (Three)
				{
					ServidorTres->Operate();
				}
			}
			else
			{
				if (Three)
				{
					ServidorTres->Operate();
				}
				if (Two)
				{
					ServidorDos->Operate();
				}
			}
		}
		else if (ServerOne == ServerTwo && ServerOne > ServerThree)
		{
			if (Three)
			{
				ServidorTres->Operate();
			}
			ServerOne = ServidorUno->Movements();
			ServerTwo = ServidorDos->Movements();

			if (ServerOne < ServerTwo)
			{
				if (One)
				{
					ServidorUno->Operate();
				}
				if (Two)
				{
					ServidorDos->Operate();
				}
			}
			else
			{
				if (Two)
				{
					ServidorDos->Operate();
				}
				if (One)
				{
					ServidorUno->Operate();
				}
			}
		}
		else if (ServerOne == ServerThree && ServerOne < ServerTwo)
		{
			if (One)
			{
				ServidorUno->Operate();
			}
			ServerTwo = ServidorDos->Movements();
			ServerThree = ServidorTres->Movements();
			if (ServerTwo < ServerThree)
			{
				if (Two)
				{
					ServidorDos->Operate();
				}
				if (Three)
				{
					ServidorTres->Operate();
				}
			}
			else
			{
				if (Three)
				{
					ServidorTres->Operate();
				}
				if (Two)
				{
					ServidorDos->Operate();
				}
			}
		}
		else if (ServerOne == ServerThree && ServerOne > ServerTwo)
		{
			if (Two)
			{
				ServidorDos->Operate();
			}
			ServerOne = ServidorUno->Movements();
			ServerThree = ServidorTres->Movements();

			if (ServerOne < ServerThree)
			{
				if (One)
				{
					ServidorUno->Operate();
				}
				if (Three)
				{
					ServidorTres->Operate();
				}
			}
			else
			{
				if (Three)
				{
					ServidorTres->Operate();
				}
				if (One)
				{
					ServidorUno->Operate();
				}
			}
		}
		else if (ServerTwo == ServerThree && ServerTwo < ServerOne)
		{
			if (Two)
			{
				ServidorDos->Operate();
			}
			ServerOne = ServidorUno->Movements();
			ServerThree = ServidorTres->Movements();

			if (ServerOne < ServerThree)
			{
				if (One)
				{
					ServidorUno->Operate();
				}
				if (Three)
				{
					ServidorTres->Operate();
				}
			}
			else
			{
				if (Three)
				{
					ServidorTres->Operate();
				}
				if (One)
				{
					ServidorUno->Operate();
				}
			}
		}
		else if (ServerTwo == ServerThree && ServerTwo > ServerOne)
		{
			if (One)
			{
				ServidorUno->Operate();
			}
			ServerTwo = ServidorDos->Movements();
			ServerThree = ServidorTres->Movements();

			if (ServerTwo < ServerThree)
			{
				if (Two)
				{
					ServidorDos->Operate();
				}
				if (Three)
				{
					ServidorTres->Operate();
				}
			}
			else
			{
				if (Three)
				{
					ServidorTres->Operate();
				}
				if (Two)
				{
					ServidorDos->Operate();
				}
			}
		}
		else
		{
			//NOTHING MUST BE END HERE. ERROR - CASE NOT EVALUATED.
			return false;
		}

		return true;
	}
	catch (const std::exception&)
	{
		
	}
}

bool BalanceadorDeCarga::Start() {
	try
	{


		if (this->Lines.size() >= 9) // Validamos que existan al menos tres peticiones disponibles
		{
			for (int i = 0; i < 3; i++)
			{
				this->Allocator(); // Llamamos a allocator que se encarga de tomar las peticiones
			}
		}
		else if (this->Lines.size() > 0)
		{
			for (int i = 0; i < Lines.size(); i++)
			{
				this->Allocator(); // Si no hay tres peticiones, entonces llamamos a allocator tantas veces como peticiones existan, Lines.size() cambiara hasta llegar a cero.
			}
		}

		//verificamos que los servidores aun tenga algo que operar, despues de asignadas todas las peticiones
		bool Server1 = ServidorUno->IsNotEmpty();
		bool Server2 = ServidorDos->IsNotEmpty();
		bool Server3 = ServidorTres->IsNotEmpty();

		if (Server1 == false && Server2 == false && Server3 == false && Lines.size() == 0)
		{
			return false; // retornara false cuando ya no existan peticiones pendientes en los servidores.
		}
		else
		{
			this->Operate(); // Sino llamaos a este metodo para que se le den instrucciones de operar a cada servidor.
			this->Log->push_back("out"); // agregamo un punto de cambio, aqui ha terminado el tick actual
			return true;
		}
	}
	catch (const std::exception&)
	{
		cout << "A GENERAL ERROR OCCURRED. MAYBE THE PETITIONS DO NOT HAVE CORRECT FORMAT?" << endl;
		cin.get();
		exit(0);
	}
}

void BalanceadorDeCarga::ToUnsuccessful(int _operation, string _id, string values) {
	try
	{
		// envia las peticiones fallidas a la cola de peticiones fallidas.
		string Operation = "";
		string ram = "";
		string processor = "";
		switch (_operation)
		{
		case 0:
			Operation = "SUM";
			break;
		case 1:
			Operation = "SUB";
			break;
		case 2:
			Operation = "MUL";
			break;
		case 3:
			Operation = "DIV";
			break;
		case 4:
			Operation = "NEG";
			break;
		default:
			Operation = "NULL";
			break;
		}
		
		this->Unsuccessful->push_back("UNSUCCESSFUL PETITION: " + Operation + "\nID: " + _id + "\nValues: " + values + "\n");
		this->Log->push_back("\t\t!!! WARNING !!! \n\tServers did not received the incoming petition: " + Operation + "\n\tID: " + _id + "\nValues: " + values);
	}
	catch (const std::exception&)
	{
		cout << "AN ERROR OCCURRED WHILE SAVING AN UNSUCCSSFUL PETITION. MAYBE THE ARRAY IS FULL OR OUT  OF RANGE?" << endl;
		cin.get();
		exit(0);
	}
}