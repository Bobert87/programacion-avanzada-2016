#include "stdafx.h"
#include "HardDrive.h"


HardDrive::HardDrive()
{
}

void HardDrive::Move(int x) {
	this->Section = x;
}
int HardDrive::Position() {
	return this->Section;
}
HardDrive::~HardDrive()
{
}
