#pragma once
#include "stdafx.h"
#include "Cola.cpp"
#include <iostream>
#include <vector>
#include "HardDrive.h"
#include <string>
using namespace std;
class Servers
{
public:
	
	Servers(int _ram, int _processor, int _petitions, string _name, HardDrive *Drive, vector<string> *_successful, vector<string> *_log);
	~Servers();

	bool IsNotEmpty();
	bool IsUsed();
	bool AcceptPetition(int _operation);
	bool AssignValues(int _operation, string _id, string values, Cola _memory, Cola _processor);
	int Movements();
	int HardDrivePosition();
	bool Operate();
private:

	//METHODS

	bool MemoryDequeue();
	int ProcessorDequeue();
	bool MemoryQueue(int _value);
	bool ProcessorQueue(int _value);
	bool SubstractPetitions(int Used);
	int ValuesInProcessorOfFirstPetitionInQueue();
	int OperateMemory();
	string ToSuccessful();
	string NameOfPetition(int x);
	// REAL RAM AND PROCESSOR
	Cola* Memory = new Cola();
	Cola* Processor = new Cola();
	
	//VARIABLES

	Cola *PetitionsQueue = new Cola();
	vector<string> *PetitionsID = new vector<string>;
	vector<string> *PetitionsValues = new vector<string>;

	int Operations = 0;
	int Petitions = 0;
	int Ram = 0;
	int Process = 0;

	string Name = "";
	HardDrive *Drive;
	vector<string> *Successful;
	bool Used = false;
	vector<string> *Log;
};

