#pragma once
#include "Cola.cpp"
class HardDrive
{
public:

	void Move(int x);
	int Position();
	HardDrive();
	~HardDrive();
private:

	int Section = 1;
	
};

